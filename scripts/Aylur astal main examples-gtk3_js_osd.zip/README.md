# On Screen Display

![osd](https://github.com/user-attachments/assets/08e0e118-6b07-4cac-8ebc-08262594cee7)

A simple widget that pops up when screen brightness or audio changes

Uses the [WirePlumber library](https://aylur.github.io/astal/guide/libraries/wireplumber).
